class ActionResult(object):

    def __init__(self):
        self.type = "type"
        self.id = "id"
        self.exception = "exception"
        self.result = "result"
        self.info = "info"
        self.transInfo = "transInfo"
#1
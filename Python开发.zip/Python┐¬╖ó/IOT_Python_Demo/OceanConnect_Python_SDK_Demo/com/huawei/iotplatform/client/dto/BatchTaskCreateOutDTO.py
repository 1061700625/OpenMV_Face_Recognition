class BatchTaskCreateOutDTO(object):

    def __init__(self):
        self.taskID = None

    def getTaskID(self):
        return self.taskID

    def setTaskID(self, taskID):
        self.taskID = taskID

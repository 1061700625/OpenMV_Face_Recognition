class CommandDTOV4(object):
    serviceId = "serviceId"
    method = "method"
    paras = "paras"
    # def __init__(self):
    #     self.paras = "paras:{}"


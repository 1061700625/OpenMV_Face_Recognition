class ConditionReason(object):

    def __init__(self):
        self.satisfactionTime = "satisfactionTime"
        self.type = "type"
        self.id = "id"
        self.info = "info"
        self.transInfo = "transInfo"
#1
from com.huawei.iotplatform.client.dto.Identifier import Identifier


class CoordinateReferenceSystem(object):
    identifier = Identifier
#1
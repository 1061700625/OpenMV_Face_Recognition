class CreateUpgradeTaskOutDTO(object):

    def __init__(self):
        self.operationId = None

    def getOperationId(self):
        return self.operationId

    def setOperationId(self, operationId):
        self.operationId = operationId

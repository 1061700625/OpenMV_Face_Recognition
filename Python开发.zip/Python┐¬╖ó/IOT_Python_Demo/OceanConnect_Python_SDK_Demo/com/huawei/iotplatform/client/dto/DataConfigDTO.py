class DataConfigDTO(object):
    # dataAgingTime = "dataAgingTime"

    def __init__(self):
        self.dataAgingTime = None

    def getDataAgingTime(self):
        return self.dataAgingTime

    def setDataAgingTime(self, dataAgingTime):
        self.dataAgingTime = dataAgingTime

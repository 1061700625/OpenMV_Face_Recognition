class DeviceEventHeader(object):

    def __init__(self):
        self.requestId = "requestId"
        self.from_ = "from_"
        self.to = "to"
        self.deviceId = "deviceId"
        self.serviceType = "serviceType"
        self.method = "method"

#1
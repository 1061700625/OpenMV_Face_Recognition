class Identifier(object):
    code = str
    codeSpace = str
    edition = str
#1
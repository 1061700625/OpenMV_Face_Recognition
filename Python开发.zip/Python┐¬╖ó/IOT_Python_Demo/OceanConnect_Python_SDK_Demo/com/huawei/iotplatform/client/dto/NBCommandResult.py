class NBCommandResult(object):

    def __init__(self):
        self.resultCode = "resultCode"
        self.resultDetail = "resultDetail"

    def getResultCode(self):
        return self.resultCode

    def setResultCode(self, resultCode):
        self.resultCode = resultCode

    def getResultDetail(self):
        return self.resultDetail

    def setResultDetail(self, resultDetail):
        self.resultDetail = resultDetail
class RuleCreateOrUpdateOutDTO(object):

    def __init__(self):
        self.ruleId = None

    def getRuleId(self):
        return self.ruleId

    def setRuleId(self, ruleId):
        self.ruleId = ruleId

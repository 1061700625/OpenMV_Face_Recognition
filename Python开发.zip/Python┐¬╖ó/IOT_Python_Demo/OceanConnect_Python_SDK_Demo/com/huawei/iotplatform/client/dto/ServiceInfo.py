class ServiceInfo(object):

    def __init__(self):
        self.muteCmds = "muteCmds"

    def getMuteCmds(self):
        return self.muteCmds

    def setMuteCmds(self, muteCmds):
        self.muteCmds = muteCmds
class UpdateBatchRuleStatusOutDTO(object):

    def __init__(self):
        self.ddd = None
        self.ddd = None
        self.ddd = None
        self.ddd = None
        self.ddd = None
#1
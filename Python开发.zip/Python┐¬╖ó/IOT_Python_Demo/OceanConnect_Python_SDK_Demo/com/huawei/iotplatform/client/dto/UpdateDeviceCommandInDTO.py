class UpdateDeviceCommandInDTO(object):

    def __init__(self):
        self.status = None

    def getStatus(self):
        return self.status

    def setStatus(self, status):
        self.status = status

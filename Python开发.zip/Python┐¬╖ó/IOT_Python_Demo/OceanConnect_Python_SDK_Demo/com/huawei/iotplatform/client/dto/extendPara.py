class extendPara(object):

    def __init__(self):
        self.fileVersion = None

    def getFileVersion(self):
        return self.fileVersion

    def setFileVersion(self, fileVersion):
        self.fileVersion = fileVersion

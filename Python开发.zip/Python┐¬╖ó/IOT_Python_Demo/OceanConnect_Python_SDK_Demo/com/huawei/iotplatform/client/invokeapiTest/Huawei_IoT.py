import json
from time import sleep

from OceanConnect_Python_SDK.com.huawei.iotplatform.client.invokeapi.Authentication import Authentication
from OceanConnect_Python_SDK.com.huawei.iotplatform.client.invokeapi.SignalDelivery import SignalDelivery
from com.huawei.iotplatform.client.dto.AuthOutDTO import AuthOutDTO
from com.huawei.iotplatform.client.dto.CreateDeviceCmdCancelTaskInDTO import CreateDeviceCmdCancelTaskInDTO
from com.huawei.iotplatform.client.dto.PostDeviceCommandInDTO import PostDeviceCommandInDTO
from com.huawei.iotplatform.client.dto.PostDeviceCommandOutDTO import PostDeviceCommandOutDTO
from com.huawei.iotplatform.client.dto.QueryDeviceCmdCancelTaskInDTO import QueryDeviceCmdCancelTaskInDTO
from com.huawei.iotplatform.client.dto.QueryDeviceCommandInDTO import QueryDeviceCommandInDTO
from com.huawei.iotplatform.client.dto.UpdateDeviceCommandInDTO import UpdateDeviceCommandInDTO
from com.huawei.iotplatform.constant.Constant import Constant
from OceanConnect_Python_SDK.com.huawei.iotplatform.client.invokeapi.DataCollection import DataCollection
from com.huawei.iotplatform.client.dto.QueryBatchDevicesInfoInDTO import QueryBatchDevicesInfoInDTO
from com.huawei.iotplatform.client.dto.QueryDeviceCapabilitiesInDTO import QueryDeviceCapabilitiesInDTO
from com.huawei.iotplatform.client.dto.QueryDeviceDataHistoryInDTO import QueryDeviceDataHistoryInDTO
from com.huawei.iotplatform.client.dto.QueryDeviceDesiredHistoryInDTO import QueryDeviceDesiredHistoryInDTO


class SignalDeliveryTest(object):
    def postDeviceCommandInfo(self, method, serviceId, paras):
        pdcInDTO = PostDeviceCommandInDTO()
        pdcInDTO.deviceId = deviceId
        pdcInDTO.command = {
            pdcInDTO.command.method: method,
            pdcInDTO.command.serviceId: serviceId,
            pdcInDTO.command.paras: paras}
        return pdcInDTO

    def updateDeviceCommandInfo(self):
        udcInDTO = UpdateDeviceCommandInDTO()
        udcInDTO.status = "CANCELED"  # 撤销命令
        return udcInDTO

    def queryDeviceCommandInfo(self):
        qdcInDTO = QueryDeviceCommandInDTO()
        qdcInDTO.deviceId = "7bf90edf-eabf-48a5-8a3e-1509dcb8ad5d"
        qdcInDTO.pageSize = "2"
        return qdcInDTO

    def createDeviceCmdCancelTaskInfo(self):
        cdcctInDTO = CreateDeviceCmdCancelTaskInDTO()
        cdcctInDTO.deviceId = "7bf90edf-eabf-48a5-8a3e-1509dcb8ad5d"
        return cdcctInDTO

    def queryDeviceCmdCancelTaskInfo(self):
        qdcctInDTO = QueryDeviceCmdCancelTaskInDTO()
        qdcctInDTO.deviceId = "7bf90edf-eabf-48a5-8a3e-1509dcb8ad5d"
        return qdcctInDTO

class DataCollectionTest(object):
    def __init__(self):
        self.deviceId = deviceId
        self.gatewayId = gatewayId
        self.appId = appId

    def queryBatchDevicesInfo(self):
        qbdiInDTO = QueryBatchDevicesInfoInDTO()
        qbdiInDTO.gatewayId = self.gatewayId
        qbdiInDTO.appId = self.appId
        return qbdiInDTO

    def queryDeviceDataHistory(self):
        qddhInDTO = QueryDeviceDataHistoryInDTO()
        qddhInDTO.deviceId = self.deviceId
        qddhInDTO.gatewayId = self.gatewayId
        qddhInDTO.appId = self.appId
        return qddhInDTO

    def queryDeviceDesiredHistory(self):
        qddhInDTO = QueryDeviceDesiredHistoryInDTO()
        qddhInDTO.deviceId = self.deviceId
        qddhInDTO.gatewayId = self.gatewayId
        qddhInDTO.appId = self.appId
        return qddhInDTO

    def queryDeviceCapabilities(self):
        qdcInDTO = QueryDeviceCapabilitiesInDTO()
        qdcInDTO.deviceId = self.deviceId
        qdcInDTO.gatewayId = self.gatewayId
        qdcInDTO.appId = self.appId
        return qdcInDTO


class Tasker_Control(object):
    def __init__(self, accessToken):
        self.sdTest = SignalDeliveryTest()
        self.signalDelivery = SignalDelivery()
        self.accessToken = accessToken

    def post_device_command(self, ctrl_method="control", ctrl_serviceId="DoorLock", ctrl_paras={}):
        ctrl_paras = ctrl_paras or {"Lock": "LOCK"}
        self.sp = self.signalDelivery.postDeviceCommand(self.sdTest.postDeviceCommandInfo(ctrl_method, ctrl_serviceId, ctrl_paras), None, self.accessToken)
        print("====== post an NB-IoT device command ======")
        print("result:", self.sp + "\n")

    def get_commandId_And_deviceId(self):
        pdcOutDTO = PostDeviceCommandOutDTO()
        pdcOutDTO.setCommandId(json.loads(self.sp)['commandId'])
        self.commandId = pdcOutDTO.getCommandId()
        pdcOutDTO.setDeviceId(json.loads(self.sp)['deviceId'])
        self.deviceId = pdcOutDTO.getDeviceId()
        print("commandId==", self.commandId)
        print("deviceId==", self.deviceId + "\n")

    def update_device_command(self):# 修改->设备命令
        self.su = self.signalDelivery.updateDeviceCommand(self.sdTest.updateDeviceCommandInfo(), self.commandId, None, self.accessToken)
        print("====== update device command ======")
        print("result:", self.su + "\n")

    def query_device_commands(self):# 查询->设备命令
        self.sq = self.signalDelivery.queryDeviceCommand(self.sdTest.queryDeviceCommandInfo(), self.accessToken)
        print("====== query device commands ======")
        print("result:", self.sq + "\n")

    def cancel_all_device_commands(self): #创建->设备命令撤销所有任务
        self.sc = self.signalDelivery.createDeviceCmdCancelTask(self.sdTest.createDeviceCmdCancelTaskInfo(), None, self.accessToken)
        print("====== cancel all device commands of the device ======")
        print("result:", self.sc + "\n")

    def query_device_command_cancel_tasks(self):# 查询->设备命令撤销任务
        self.sc = self.signalDelivery.queryDeviceCmdCancelTask(self.sdTest.queryDeviceCmdCancelTaskInfo(), self.accessToken)
        print("====== query device command cancel tasks of the device ======")
        print("result:", self.sc + "\n")

class Tasker_Msg(object):
    def __init__(self, accessToken):
        self.dcTest = DataCollectionTest()
        self.dataCollection = DataCollection()
        self.accessToken = accessToken
        self.deviceId = deviceId

    def query_device_capabilities(self):  # 查询->设备服务能力
        self.dq = self.dataCollection.queryDeviceCapabilities(self.dcTest.queryDeviceCapabilities(), self.accessToken)
        print("====== query device capabilities ======")
        print("result:", self.dq + "\n")

    def query_device_info(self):  # 查询->设备信息
        self.dq = self.dataCollection.querySingleDeviceInfo(self.deviceId, None, None, self.accessToken)
        print("====== query device info ======")
        print("result:", self.dq + "\n")

    def query_batch_device_info(self):  # 查询->批处理设备信息
        self.dataCollection.queryBatchDevicesInfo(self.dcTest.queryBatchDevicesInfo(), self.accessToken)
        print("====== query batch device info ======")
        print("result:", self.dq + "\n")

    def query_device_data_history(self):  # 查询->设备数据历史
        self.dq = self.dataCollection.queryDeviceDataHistory(self.dcTest.queryDeviceDataHistory(), self.accessToken)
        print("====== query device data history ======")
        print("result:", self.dq + "\n")

    def query_device_desired_history(self):  # 查询->设备所需历史记录
        self.dq = self.dataCollection.queryDeviceDesiredHistory(self.dcTest.queryDeviceDesiredHistory(), self.accessToken)
        print("====== query device desired history ======")
        print("result:", self.dq + "\n")

    def query_device_desired_capabilities(self):  # 查询->设备所需功能
        self.dq = self.dataCollection.queryDeviceCapabilities(self.dcTest.queryDeviceCapabilities(), self.accessToken)
        print("====== query device desired capabilities ======")
        print("result:", self.dq + "\n")

def get_accessToken():
    authentication = Authentication()
    result = authentication.getAuthToken(Constant().clientInfo())
    authOutDTO = AuthOutDTO()
    authOutDTO.setAccessToken(json.loads(result)['accessToken'])
    accessToken = authOutDTO.getAccessToken()
    print("accessToken:", accessToken)
    return accessToken



deviceId  = "96643d56-77db-4642-a7b8-a1a0214e9bdd"
gatewayId = "96643d56-77db-4642-a7b8-a1a0214e9bdd"
appId     = "mquj2VxejJiM3U9k7mSa5V8Eo_wa"

if __name__ == "__main__":
    accessToken = get_accessToken()

    LED_Msg = Tasker_Msg(accessToken)
    LED_Control = Tasker_Control(accessToken)

    LED_Msg.query_device_info()
    LED_Msg.query_device_capabilities()
    LED_Msg.query_device_data_history()

    LED_Control.post_device_command(ctrl_method="control", ctrl_serviceId="DoorLock", ctrl_paras={"Lock": "LOCK"})
    LED_Control.get_commandId_And_deviceId()
    LED_Control.query_device_commands()






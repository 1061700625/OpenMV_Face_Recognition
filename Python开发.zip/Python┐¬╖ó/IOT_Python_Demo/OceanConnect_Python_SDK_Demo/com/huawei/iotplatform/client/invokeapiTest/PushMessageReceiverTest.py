from com.huawei.iotplatform.client.invokeapi.PushMessageReceiver import app

if __name__ == '__main__':
    callbackUrl = "ncurobot.club"
    port = 8888

    # app.run(host=callbackUrl, port=port, ssl_context='adhoc')
    app.run(host=callbackUrl, port=port, ssl_context=(r'C:/Users/SXF/Desktop/IOT_Python_Demo/cert/client.crt',r'C:/Users/SXF/Desktop/IOT_Python_Demo/cert/client.key'))

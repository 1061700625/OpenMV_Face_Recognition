import json

from OceanConnect_Python_SDK.com.huawei.iotplatform.client.invokeapi.Authentication import Authentication
from OceanConnect_Python_SDK.com.huawei.iotplatform.client.invokeapi.SignalDelivery import SignalDelivery

from com.huawei.iotplatform.client.dto.AuthOutDTO import AuthOutDTO
from com.huawei.iotplatform.client.dto.CreateDeviceCmdCancelTaskInDTO import CreateDeviceCmdCancelTaskInDTO
from com.huawei.iotplatform.client.dto.PostDeviceCommandInDTO import PostDeviceCommandInDTO
from com.huawei.iotplatform.client.dto.PostDeviceCommandOutDTO import PostDeviceCommandOutDTO
from com.huawei.iotplatform.client.dto.QueryDeviceCmdCancelTaskInDTO import QueryDeviceCmdCancelTaskInDTO
from com.huawei.iotplatform.client.dto.QueryDeviceCommandInDTO import QueryDeviceCommandInDTO
from com.huawei.iotplatform.client.dto.UpdateDeviceCommandInDTO import UpdateDeviceCommandInDTO
from com.huawei.iotplatform.constant.Constant import Constant


class SignalDeliveryTest(object):
    def postDeviceCommandInfo(self):
        pdcInDTO = PostDeviceCommandInDTO()
        pdcInDTO.deviceId = "7bf90edf-eabf-48a5-8a3e-1509dcb8ad5d"
        pdcInDTO.command = {
            pdcInDTO.command.method: "Control",
            pdcInDTO.command.serviceId: "LEDService",
            pdcInDTO.command.paras: {'LED': 'ON'}}
        return pdcInDTO

    def updateDeviceCommandInfo(self):
        udcInDTO = UpdateDeviceCommandInDTO()
        udcInDTO.status = "CANCELED"  # 撤销命令
        return udcInDTO

    def queryDeviceCommandInfo(self):
        qdcInDTO = QueryDeviceCommandInDTO()
        qdcInDTO.deviceId = "7bf90edf-eabf-48a5-8a3e-1509dcb8ad5d"
        qdcInDTO.pageSize = "2"
        return qdcInDTO

    def createDeviceCmdCancelTaskInfo(self):
        cdcctInDTO = CreateDeviceCmdCancelTaskInDTO()
        cdcctInDTO.deviceId = deviceId
        return cdcctInDTO

    def queryDeviceCmdCancelTaskInfo(self):
        qdcctInDTO = QueryDeviceCmdCancelTaskInDTO()
        qdcctInDTO.deviceId = deviceId
        return qdcctInDTO


class TaskerMain(object):
    def __init__(self):
        self.sdTest = SignalDeliveryTest()
        self.authentication = Authentication()
        self.signalDelivery = SignalDelivery()

    def get_accessToken(self):
        result = self.authentication.getAuthToken(Constant().clientInfo())
        authOutDTO = AuthOutDTO()
        authOutDTO.setAccessToken(json.loads(result)['accessToken'])
        self.accessToken = authOutDTO.getAccessToken()
        print("accessToken:", self.accessToken)

    def post_device_command(self):
        self.sp = self.signalDelivery.postDeviceCommand(self.sdTest.postDeviceCommandInfo(), None, self.accessToken)
        print("====== post an NB-IoT device command ======")
        print("result:", self.sp + "\n")

    def get_commandId_And_deviceId(self):
        pdcOutDTO = PostDeviceCommandOutDTO()
        pdcOutDTO.setCommandId(json.loads(self.sp)['commandId'])
        self.commandId = pdcOutDTO.getCommandId()
        pdcOutDTO.setDeviceId(json.loads(self.sp)['deviceId'])
        self.deviceId = pdcOutDTO.getDeviceId()
        print("commandId==", self.commandId)
        print("deviceId==", self.deviceId + "\n")

    def update_device_command(self):# 修改->设备命令
        self.su = self.signalDelivery.updateDeviceCommand(self.sdTest.updateDeviceCommandInfo(), self.commandId, None, self.accessToken)
        print("====== update device command ======")
        print("result:", self.su + "\n")

    def query_device_commands(self):# 查询->设备命令
        self.sq = self.signalDelivery.queryDeviceCommand(self.sdTest.queryDeviceCommandInfo(), self.accessToken)
        print("====== query device commands ======")
        print("result:", self.sq + "\n")

    def cancel_all_device_commands(self): #创建->设备命令撤销所有任务
        self.sc = self.signalDelivery.createDeviceCmdCancelTask(self.sdTest.createDeviceCmdCancelTaskInfo(), None, self.accessToken)
        print("====== cancel all device commands of the device ======")
        print("result:", self.sc + "\n")

    def query_device_command_cancel_tasks(self):# 查询->设备命令撤销任务
        self.sc = self.signalDelivery.queryDeviceCmdCancelTask(self.sdTest.queryDeviceCmdCancelTaskInfo(), self.accessToken)
        print("====== query device command cancel tasks of the device ======")
        print("result:", self.sc + "\n")

if __name__ == "__main__":
    LEDService = TaskerMain()
    LEDService.get_accessToken()
    LEDService.post_device_command()
    LEDService.get_commandId_And_deviceId()
    LEDService.query_device_commands()
    # sdTest = SignalDeliveryTest()
    # authentication = Authentication()
    # signalDelivery = SignalDelivery()
    #
    # # get accessToken at first
    # result = authentication.getAuthToken(Constant().clientInfo())
    # authOutDTO = AuthOutDTO()
    # authOutDTO.setAccessToken(json.loads(result)['accessToken'])
    # accessToken = authOutDTO.getAccessToken()
    #
    # # post an NB-IoT device command 创建->设备命令
    # sp = signalDelivery.postDeviceCommand(sdTest.postDeviceCommandInfo(), None, accessToken)
    # print("====== post an NB-IoT device command ======")
    # print("result:", sp + "\n")
    #
    # # get commandId And deviceId
    # pdcOutDTO = PostDeviceCommandOutDTO()
    # pdcOutDTO.setCommandId(json.loads(sp)['commandId'])
    # commandId = pdcOutDTO.getCommandId()
    # pdcOutDTO.setDeviceId(json.loads(sp)['deviceId'])
    # deviceId = pdcOutDTO.getDeviceId()
    # print("commandId==", commandId)
    # print("deviceId==", deviceId + "\n")
    #
    # # update device command 修改->设备命令
    # su = signalDelivery.updateDeviceCommand(sdTest.updateDeviceCommandInfo(), commandId, None, accessToken)
    # print("====== update device command ======")
    # print("result:", su + "\n")
    #
    # # query device commands 查询->设备命令
    # sq = signalDelivery.queryDeviceCommand(sdTest.queryDeviceCommandInfo(), accessToken)
    # print("====== query device commands ======")
    # print("result:", sq + "\n")
    #
    # # cancel all device commands of the device 创建->设备命令撤销所有任务
    # sc = signalDelivery.createDeviceCmdCancelTask(sdTest.createDeviceCmdCancelTaskInfo(), None, accessToken)
    # print("====== cancel all device commands of the device ======")
    # print("result:", sc + "\n")
    #
    # # query device command cancel tasks of the device 查询->设备命令撤销任务
    # sc = signalDelivery.queryDeviceCmdCancelTask(sdTest.queryDeviceCmdCancelTaskInfo(), accessToken)
    # print("====== query device command cancel tasks of the device ======")
    # print("result:", sc + "\n")
